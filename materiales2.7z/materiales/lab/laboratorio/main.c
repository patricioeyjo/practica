#include <stdio.h>
#include <stdlib.h>

int main()
{
int contador=0;
int acumulador=0;
int edad;
int promedio;
/*#include<ctype.h>
maximos y minimos el primer numero que aparece es maximo y minimo
int valor,min,max,flag=0;
char respuesta
do{
    printf("ingrese un valor");
    scanf("%d",&valor);
    if(flag==0||valor>max)
        {
        max=valor
        }
        if(flag==0||valor<min)
            {
            min=valor;
            flag=1;
            }
           do
            {
            printf("continuar [s/n]:?";
            fflush(stdin);
            scanf("%c",&respuesta);
            respuesta=toupper(respuesta);
            }while(respuesta !="S" && respuesta !="N");
  }while(respuesta == "S");
  printf("el maximo es: %d\n el minimo es: %d",max,min);
  return 0;

*/ //toupper pasa a mayuscula y tolower pasa a minuscula.
}
