#include <stdio.h>
#include <stdlib.h>

int main()
{
char hora;
printf("hora: ");
fflush(stdin);
scanf("%c",&hora);
switch(hora)
    {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
            printf("a dormir");
            break;
        case '7':
        case '8':
            printf("buenos dias");
            break;
        default:
            printf("disfruta el dia");
            break;
    }
}
