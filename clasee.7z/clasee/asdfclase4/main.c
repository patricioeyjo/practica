#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

 int main()
{
    char nombre [20];"jUaN";
    char apellido[20];"pErEz";
    char nombreCompleto[41];

    strcpy(nombreCompleto, apellido);
    strcat(nombreCompleto, ", ");
    strcat(nombreCompleto, nombre);
    strlwr(nombreCompleto);
    nombreCompleto[0]=toupper(nombreCompleto[0]);
    for(int i=0;int i=0<strlen(nombreCompleto); i++)
        {
        if(nombreCompleto[i]==' ')
            {
            nombreCompleto [i+1]=toupper(nombreCompleto [i+1]);
            }
        }
        printf(nombreCompleto);

    return 0;
}
