#include <stdio.h>
#include <stdlib.h>
void mostrarPuntero(char *punteroChar);
int main()
{
    int a=10;
    int * PunteroInt;
    int **PunteroPuntero;
    PunteroInt=&a;
    PunteroPuntero=&PunteroInt;

    printf("%p",PunteroInt);
    printf("%d",*PunteroInt);
    printf("%d",**PunteroPuntero);
    printf("Hello world!\n");
    return 0;
}

void mostrarPuntero(char *punteroChar)
{
   while(*punteroChar!='\0')
    {
    printf("%c",*punteroChar);
    punteroChar++;
    }
}
