#include <stdio.h>
#include <stdlib.h>

typedef struct
 {
 int nombre;
 int legajo;
 char sexo;
 float sueldo;
 int estado;
 }eEmpleado;

 void entradaEmpleado()
 void mostrarEmpleados(array,tam)


void inicializarEmpleados(eEmpleado vec[],int tam)
{
for(int i=0;i<tam;i++)
    {
    vec[i].ocupado=0;
    }
}
int main()
{
   char confirma;
   eEmpleado ��lista[tam];
   inicializarEmpleados(lista,tam);
   char seguir='s';
   int opcion=0;

   do
    {
    printf("\n1.alta del empleado");
    printf("\n2.baja");
    printf("\n3.modificacion");
    printf("\n4.lista");
    printf("\n5.ordenar");
    printf("\n6.salir");
    scanf("%d",&opcion);

    switch(menu)
         {
        case 1:
            printf("alta empleado");
        break;
        case 2:
            printf("baja empleado");
        break;
        case 3:
            printf("mof�dicicacion empleado");
            system("pause");
        break;
        case 4:
            printf("ordenar empleados");
            system("pause");
        break;
        case 5:
            printf("listar empleados");
            system("pause");
        break;
        default:
        break;
          }
    } while(seguir=='s')


    return opcion;
}
