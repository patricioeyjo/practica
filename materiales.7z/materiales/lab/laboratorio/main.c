#include <stdio.h>
#include <stdlib.h>

int main()
{
int i;
for(i=0;i<10;i++)
    {
    printf("%d\n",(i+1));
    }
    system("pause");
    return 0;
}
