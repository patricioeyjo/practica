#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#define TAMAUTOR 10
#define TAMLIBRO 10
typedef struct
{
    int dia;
    int mes;
    int anio;
}eFecha;

typedef struct
{
    int codigoDeAutor;
    char apellido[31];
    char nombre[31];
    int estado;
}eAutores;

typedef struct
{
    int codigoDeLibro;
    char tituloLibreo[51];
    int codigoDeAutor;
}eLibros;

typedef struct
{
    int codigoDeSocio;
    char apellidoSocio[31];
    char nombreSocio[31];
    char sexo;
    char telefono[16];
    char email[31];
    int estado;
    eFecha fechaAsociado;

}eSocio;
typedef struct
{
    int codigoPrestamo;
    int codigoLibro;
    int codigoSocio;
    eFecha Prestamo;
}ePrestamo;


int main()
{
    eAutores vecDeAutores[TAMAUTOR]={{1,"AAA","AAAA"},{2,"BBB","BBBB"},{3,"CCC","CCCC"},{4,"DDD","DDDD"},
                                    {5,"EEE","EEEE"},{6,"FFF","FFFF"},{7,"GGG","GGGG"},{8,"HHH","HHHH"},
                                    {9,"III","IIII"},{10,"JJJ","JJJJ"}};
    eLibros vecDeLibros[TAMLIBRO]={{101,"AAA",1},{102,"BBB",2},{103,"CCC",3},{104,"DDD",4},
                                    {105,"EEE",5},{106,"FFF",6},{107,"GGG",7},{108,"HHH",8},
                                    {109,"III",9},{110,"JJJ",10}};

    return 0;
}

int menu()
{
    int opcion;

    system("cls");
    printf("---------------ABM --------------\n");
    printf("1.Alta socio\n");
    printf("2.Baja socio\n");
    printf("3.Modificacion\n");
    printf("4.Listar\n");
    printf("5.Listar libros\n");
    printf("6.Listar autores\n");
    printf("7.Prestamos\n");
    printf("7.Salir\n");
    printf("Elija una opcion:");
    scanf("%d",&opcion);

    return opcion;
}

void inicializarSocio(eSocio vec[],int tam)
{
    int codigoSocioAux=100;
    int i;
    for(i=0; i<tam; i++)
    {
        vec[i].codigoDeSocio=codigoSocioAux+1;
        codigoSocioAux++;
        vec[i].estado= 0;
    }
}

int buscarLibre(eSocio vec[],int tam)
{
    int index;
    int i;
    for(i=0; i<tam; i++)
    {
        if (vec[i].estado == 0)
        {
            index = i;
            break;
        }
        else if(vec[i].estado ==1)
        {
            index = -1;
        }
    }
    return index;
}


int buscarSocio(eSocio vec[], int tam, int codigoSocio)
{
    int index = -1;
    int i;

    for(i=0; i<tam; i++)
    {
        if(vec[i].estado ==1 && vec[i].codigoDeSocio == codigoSocio)
        {
            index=i;
            break;
        }
    }

    return index;
}

void altaSocio(eSocio socio[],int tam)
{
    int auxCodigo;
    int index;
    int esta;

    index=buscarLibre(socio,tam);
    auxCodigo=socio[index].codigoDeSocio;
    if(index == -1)
    {
        printf("\nNo hay lugar en el sistema\n");
    }
    else
    {

        esta = buscarSocio(socio, tam, auxCodigo);

        if(esta != -1)
        {
            printf("Existe un socio con el codigo %d en el sistema\n", auxCodigo);

        }
        else
            {
            getString("ingrese apellido",socio[index].apellidoSocio);
            getString("ingrese nombre",socio[index].nombreSocio);

            printf("Ingrese sexo: ");
            fflush(stdin);
            scanf("%c", &socio[index].sexo);
                if(socio[index].sexo != 'f'&&socio[index].sexo != 'm')
                    {
                    printf("error, el sexo solo puede ser f/m");
                    }
            socio[index].sexo = toupper(socio[index].sexo);

            getStringTelefono("ingrese el numero de telefono",socio[index].telefono);
            getString("ingrese el email",socio[index].email);

            printf("Fecha de asociado\nDia:");
            scanf("%d",&socio[index].fechaAsociado.dia);

            printf("Mes:");
            scanf("%d",&socio[index].fechaAsociado.mes);

            printf("Anio:");
            scanf("%d",&socio[index].fechaAsociado.anio);

            socio[index].estado=1;

            printf("alta asociado exitosa");

            }

    }
}

void bajaEmpleado(eEmpleado empleados[], int tam)
{
    int index;
    int legajo;
    char confirma;

    printf("Ingrese legajo: ");
    scanf("%d", &legajo);
    index = buscarEmpleado(empleados,tam,legajo);

    if(index== -1)
    {
        printf("No se encontro al empleado\n");
    }
    else
    {
        printf("Desea dar de baja al empleado?\n");
        fflush(stdin);
        confirma = getch();

        if(tolower(confirma)=='s')
        {
            empleados[index].estado =0;
            printf("Baja exitosa\n");
        }
        else
        {
            printf("No se dio de baja al empleado\n");
        }
    }
}
