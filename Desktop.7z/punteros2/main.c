#include <stdio.h>
#include <stdlib.h>

int main()
{
    int* pnum;
    int* paux;
    int i;

    //realloc()
    pnum=(int*)malloc(sizeof(int)*5);
    if(pnum==NULL)
        {
        printf("no se consiguio memoria\n");
        exit(1);
        }
    *pnum=10;

    for(i=0;i<5;i++)
    {
    printf("ingrese numero: ");
    scanf("%d",pnum+i);
    }
    for(i=0;i<5;i++)
    {
    printf("\n%d\n",*(pnum+i));

    }

    paux=(int*)realloc(pnum,sizeof(int)*10);
    printf("se agrando el array");
    if(paux!=NULL)
        {
        pnum=paux;
        }else
        {
        exit(1);
        }
    for(i=5;i<10;i++)
    {
    printf("ingrese numero: ");
    scanf("%d",pnum+i);
    }
    for(i=0;i<10;i++)
    {

    printf("%d\n",*(pnum+i));
    if(i>4&&i<10)
        {
        printf("numero agregado: ");
        }

    }

    pnum=(int*)realloc(pnum,sizeof(int)*5);
    printf("se achico el array");
    for(i=0;i<10;i++)
    {

    printf("%d\n",*(pnum+i));
    }

    free(pnum);
    return 0;
}
 /*int*vec;
    int i;
    vec=(int*)calloc(10,sizeof(int)*10);

    for(i=0;i<10;i++)
        {
        printf("%d",*(vec+i));
        }*/
