#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int legajo;
    char nombre[20];
    char sexo;
    float sueldo;
}eEmpleado;
int main()
{
   eEmpleado* pemp=(eEmpleado*)malloc(sizeof(eEmpleado));
   if(pemp==NULL)
    {
    exit(1);
    }
    printf("\ningrese legajo: ");
    scanf("%d",&pemp->legajo);

    printf("\ningrese nombre: ");
    fflush(stdin);
    scanf("%s",pemp->nombre);

    printf("\ningrese sexo: ");
    fflush(stdin);
    scanf("%c",&pemp->sexo);

    printf("\ningrese sueldo: ");
    scanf("%f",&pemp->sueldo);

    printf("\nlegajo: %d   nombre: %s   sexo: %c   sueldo: %.2f\n\n",pemp->legajo,pemp->nombre,pemp->sexo,pemp->sueldo);
    return 0;
}
