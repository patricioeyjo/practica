#include <stdio.h>
#include <stdlib.h>

void mostrarPuntero(char *punteroChar);


int main()
{
    mostrarPuntero("Hola mundo!\n");
    mostrarPuntero("Argentina\n");
    mostrarPunteroDos("Estancia Mendoza\n");
    return 0;
}

void mostrarPuntero(char *punteroChar)
{
   while(*punteroChar!='\0')
    {
    printf("%c",*punteroChar);
    punteroChar++;
    }
}

void mostrarPunteroDos(char *punteroChar)
{
    int i=0;
     while(*(punteroChar+i)!='\0')
        {
        printf("%c",*(punteroChar+i));
        i++;
        }
}
