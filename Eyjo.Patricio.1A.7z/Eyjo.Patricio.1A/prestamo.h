#ifndef PRESTAMO_H_INCLUDED
#define PRESTAMO_H_INCLUDED

typedef struct
{
    int codigoPrestamo;
    int codigoLibro;
    int codigoSocio;
    int estado;
    eFecha Prestamo;
}ePrestamo;
int buscarPrestamoLibre(ePrestamo prestamo[],int tam);
int buscarPrestamoLibre(ePrestamo prestamo[],int tam);
void inicializarPrestamo(ePrestamo prestamo[],int tam);
void altaPrestamo(ePrestamo prestamos[],int tam,eSocio socios[], eLibros libros[]);

#endif // PRESTAMO_H_INCLUDED
