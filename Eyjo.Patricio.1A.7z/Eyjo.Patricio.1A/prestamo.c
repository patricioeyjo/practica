#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#include "socio.h"
#include "libros.h"
#include "prestamo.h"
#include "autor.h"

void inicializarPrestamo(ePrestamo prestamo[],int tam)
{
    int codigoPrestamoAux=1000;
    int i;
    for(i=0; i<tam; i++)
    {
        prestamo[i].codigoPrestamo=codigoPrestamoAux+1;
        codigoPrestamoAux++;
        prestamo[i].estado= 0;
    }
}

int buscarPrestamoLibre(ePrestamo prestamo[],int tam)
{
    int index;
    int i;
    for(i=0; i<tam; i++)
    {
        if (prestamo[i].estado == 0)
        {
            index = i;
            break;
        }
        else if(prestamo[i].estado ==1)
        {
            index = -1;
        }
    }
    return index;
}


int buscarPrestamo(ePrestamo prestamo[], int tam, int codigoPrestamo)
{
    int index = -1;
    int i;

    for(i=0; i<tam; i++)
    {
        if(prestamo[i].estado ==1 && prestamo[i].codigoPrestamo == codigoPrestamo)
        {
            index=i;
            break;
        }
    }

    return index;
}



void altaPrestamo(ePrestamo prestamos[],int tam,eSocio socios[], eLibros libros[])
{
    int index,indexSocio,indexLibro;
    int auxCodigo,auxCodigoLibro,auxCodigoSocio;
    int auxDia,auxMes,auxAnio;


    index = buscarPrestamoLibre(prestamos,tam);

    if(index == -1)
    {
        printf("\nNo hay prestamos disponibles\n");
    }
    else
    {
        auxCodigo= prestamos[index].codigoPrestamo;
        printf("Codigo de prestamo: %d\n",auxCodigo);

        printf("Ingrese codigo del libro: ");
        scanf("%d",&auxCodigoLibro);
        indexLibro = buscarLibro(libros,tam,auxCodigoLibro);

        if(indexLibro==-1)
        {
            printf("No se encontro el libro\n");
        }
        else
        {
            printf("Ingrese codigo del socio: ");
            scanf("%d",&auxCodigoSocio);
            indexSocio = buscarSocio(socios,tam,auxCodigoSocio);

            if(indexSocio==-1)
            {
                printf("No se encontro el socio\n");
            }else
            {
                do
                {
                    auxDia=getInt("Ingrese dia entre 1 y 31: ");
                }while(auxDia>30 || auxDia <1);
                prestamos[index].Prestamo.dia = auxDia;

                do
                {
                    auxMes=getInt("Ingrese mes entre 1 y 12: ");

                }while(auxMes>12 || auxMes <1);
                prestamos[index].Prestamo.mes = auxMes;

                do
                {
                   auxAnio=getInt("Ingrese anio entre 1900 y 2020: ");

                }while(auxAnio>2020 || auxAnio <1902);
                prestamos[index].Prestamo.anio= auxAnio;

                prestamos[index].codigoPrestamo = auxCodigo;
                prestamos[index].codigoSocio = auxCodigoSocio;
                prestamos[index].codigoLibro = auxCodigoLibro;

                prestamos[index].estado = 1;
                printf("Alta de prestamo exitosa.\nCodigo: %d  Codigo de Socio: %d  Codigo de libro: %d  Fecha de prestamo: %d/%d/%d\n",auxCodigo,prestamos[index].codigoSocio,prestamos[index].codigoLibro,prestamos[index].Prestamo);
                auxCodigo++;
            }
        }
    }
}
