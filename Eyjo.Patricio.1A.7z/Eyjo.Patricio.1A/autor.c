#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#include "socio.h"
#include "autor.h"
#include "libros.h"
#include "prestamo.h"

void listarAutores(eAutores autores[],int tam)
{
    int i,j;
    eAutores auxAutores;

    for(i=0;i<tam-1;i++)
    {
        if(autores[i].estado==0)
            {
            continue;
            }
        for(j=i+1;j<tam;j++)
        {
            if(autores[i].estado==0)
            {
            continue;
            }
            if(strcmp(autores[i].apellido,autores[j].apellido)>0)
            {
                auxAutores = autores[i];
                autores[i]= autores[j];
                autores[j]= auxAutores;
            }
        }
    }
}


int menuAutores()
{
    char opcion = '.';

    printf("\n----MENU AUTORES----\n");
    printf("A.Alta\n");
    printf("B.Modificar\n");
    printf("C.Baja\n");
    printf("D.Listar autores\n");
    printf("E.Salir\n");

    opcion=getChar("Elija una opcion: \n");
    opcion = toupper(opcion);
    return opcion;
}

void inicializarAutor(eAutores autores[], int tam)
{
    int auxCodigoAutor=0;
    int i;
    for(i=0;i<tam;i++)
    {
        autores[i].codigoDeAutor =auxCodigoAutor;
        autores[i].estado = 0;
    }
}

int buscarAutorLibre(eAutores autores[],int tam)
{
    int i;
    int index = -1;
    for(i=0; i<tam; i++)
    {
        if (autores[i].estado == 0)
        {
            index = i;
            break;
        }
    }
    return index;
}

int buscarAutor(eAutores autores[], int tam,int codigoAutor)
{
    int index = -1;
    int i;

    for(i=0; i<tam; i++)
    {
        if(autores[i].codigoDeAutor == codigoAutor  && autores[i].estado ==1 )
        {
            index=i;
            break;
        }
    }

    return index;
}

void altaAutor(eAutores autores[], int tam)
{
    int index;
    int auxCodigo;
    int validar;


    index = buscarAutorLibre(autores,tam);

    if(index == -1)
    {
        printf("\nNo hay autores disponibles\n");
    }
    else
    {
        auxCodigo=autores[index].codigoDeAutor;
        printf("Codigo de autor: %d\n",auxCodigo);

        do{
        validar = getStringLetras("Ingrese nombre: ",autores[index].nombre);
        }while(validar == 0);

       do{
        validar = getStringLetras("Ingrese apellido: ",autores[index].apellido);
        }while(validar == 0);


        autores[index].estado = 1;
        printf("Alta de autor exitosa.\nCodigo: %d  Nombre: %s Apellido: %s\n",auxCodigo,autores[index].nombre,autores[index].apellido);

    }
}

void bajaAutor(eAutores autores[], int tam)
{
    int index;
    int codigoAutor;
    char confirma;



        printf("Ingrese codigo a dar de baja: ");
        scanf("%d", &codigoAutor);
        index = buscarAutor(autores,tam,codigoAutor);

        if(index== -1)
        {
            printf("No se encontro al autor\n");
        }
        else
        {
            confirma = getChar("Desea dar de baja el autor? (S/N): ");
            confirma = toupper(confirma);
            while((confirma!= 'S') && (confirma!= 'N'))
            {
                confirma = getChar("\nerror, ingrese S o N : ");
                confirma = toupper(confirma);
            }
            if(confirma=='S')
            {
                autores[index].estado = 0;
                printf("Baja exitosa!\n");
            }
            else
            {
                printf("No se dio de baja \n");
            }
        }
}



int menuModificacionAutor()
{
    char opcion = '-';

    printf("\nModificacion Autor\n");
    printf("1.Apellido\n");
    printf("2.Nombre\n");
    printf("3.Cancelar\n");

    opcion = getChar("\nIngrese opcion entre 1 y 3: ");
    return opcion;
}


void modificacionAutor(eAutores autores[], int tam)
{

    int index;
    int codigoAutor;
    int validar;
    char auxApellido[31];
    char auxNombre[31];
    char confirma='N';

        printf("Ingrese codigo del autor a modificar: ");
        scanf("%d",&codigoAutor);
        index = buscarAutor(autores,tam,codigoAutor);
        if(index==-1)
        {
            printf("No se encontro el autor\n");
        }else{
            do{
                switch(menuModificacionAutor())
                {
                case '1':
                    printf("El apellido actual es: %s\n",autores[index].apellido);

                    validar = getStringLetras("Ingrese nuevo apellido: ",auxApellido);
                    if(validar == 0)
                        {
                        printf("\nerror, el apellido debe estar compuesto por letras");
                        break;
                        }
                    else{

                    confirma = getChar("\nSeguro quiere modificarlo? (N/S):");
                    confirma = toupper(confirma);
                    if(confirma == 'S')
                    {
                        strcpy(autores[index].apellido,auxApellido);
                    }else
                    {
                        printf("\nno se modifico el apellido");
                    }
                        }
                    system("pause");
                    break;

                case '2':
                    printf("El nombre actual es: %s\n",autores[index].nombre);
                    validar = getStringLetras("Ingrese nuevo nombre: ",auxNombre);
                    if(validar == 0)
                    {
                        printf("\nerror, el nombre debe estar compuesto por letras");
                    }
                    else{

                    confirma = getChar("Seguro quiere modificarlo? (N/S):");
                    confirma = toupper(confirma);

                    if(confirma == 'S')
                    {
                        strcpy(autores[index].nombre,auxNombre);
                    }else
                    {
                    printf("\nno se modifico el nombre");
                    }
                        }
                    system("pause");
                    break;

                case '3':
                    confirma = getChar("\nSeguro quiere salir? (N/S): ");
                    confirma = toupper(confirma);

                    if(confirma == 'S')
                    {
                        confirma = 'N';
                    }
                    break;
                default:
                    printf("Ingrese opcion correcta \n");
                    system("pause");
                }
            }while (confirma == 'S');
        }
}

