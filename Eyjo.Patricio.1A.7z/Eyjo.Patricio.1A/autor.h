#ifndef AUTOR_H_INCLUDED
#define AUTOR_H_INCLUDED

typedef struct
{
    int codigoDeAutor;
    char apellido[31];
    char nombre[31];
    int estado;
}eAutores;

int menuAutores();
void listarAutores(eAutores autores[],int tam);
void inicializarAutor(eAutores autores[], int tam);
int buscarAutorLibre(eAutores autores[],int tam);
int buscarAutor(eAutores autores[], int tam,int codigoAutor);
void altaAutor(eAutores autores[], int tam);
void bajaAutor(eAutores autores[], int tam);
int menuModificacionAutor();
void modificacionAutor(eAutores autores[], int tam);


#endif // AUTOR_H_INCLUDED
