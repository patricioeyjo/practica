#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "autor.h"
#include "utn.h"
#include "socio.h"
#include "libros.h"
#include "prestamo.h"

void listarLibros(eLibros libros[],int tam)
{
    int i,j;
    eLibros auxLibros;

    printf("\n LISTADO DE LIBROS POR TITULO \n\n");
    for(i=0;i<tam-1;i++)
    {
        if(libros[i].estado==0)
            {
            continue;
            }
        for(j=i+1;j<tam;j++)
        {
            if(libros[i].estado==0)
            {
            continue;
            }
            if(strcmp(libros[i].tituloLibro,libros[j].tituloLibro)>0)
            {
                auxLibros = libros[j];
                libros[j]= libros[i];
                libros[i]= auxLibros;
            }
        }
    }
}

int menuLibros()
{
    char opcion = '.';

    printf("\n----MENU LIBROS----\n");
    printf("A.Alta\n");
    printf("B.Modificar\n");
    printf("C.Baja\n");
    printf("D.Listar libros\n");
    printf("E.Salir\n");

    opcion=getChar("Elija una opcion: \n");
    opcion = toupper(opcion);
    return opcion;
}

int menuModificacionLibro()
{
    char opcion = '0';

    printf("\n----MODIFICACION LIBRO----\n");
    printf("1.Titulo\n");
    printf("2.Codigo de autor\n");
    printf("3.Cancelar\n");

    opcion = getChar("\nIngrese opcion entre 1 y 3: ");
    return opcion;
}


void inicializarLibro(eLibros libros[], int tam)
{
    int auxCodigoLibro=0;
    int i;
    for(i=0;i<tam;i++)
    {
        libros[i].codigoDeLibro = auxCodigoLibro+1;
        auxCodigoLibro++;
        libros[i].estado = 0;
    }
}

int buscarLibroLibre(eLibros libros[],int tam)
{
    int index = -1;
    int i = 0;
    for(i=0; i<tam; i++)
    {
        if (libros[i].estado == 0)
        {
            index = i;
            break;
        }
    }
    return index;
}

int buscarLibro(eLibros libros[], int tam,int codigo)
{
    int index = -1;
    int i;

    for(i=0; i<tam; i++)
    {
        if(libros[i].codigoDeLibro == codigo)
        {
            index=i;
            break;
        }
    }

    return index;
}
void altaLibro(eLibros libros[], int tam, eAutores autores[])
{
    int indexLibros;
    int indexAutores;
    int auxCodigoLibro;
    int auxCodigoAutor;
    int validar;
    char auxTitulo[51];


    indexLibros = buscarLibroLibre(libros,tam);

    if(indexLibros == -1)
    {
        printf("\nNo hay libros disponibles\n");
    }
    else
    {
        auxCodigoLibro=libros[indexLibros].codigoDeLibro;
        printf("Codigo de libro: %d\n",auxCodigoLibro);

        printf("Ingrese codigo de autor: ");
        scanf("%d",&auxCodigoAutor);
        indexAutores = buscarAutor(autores,tam,auxCodigoAutor);

        if(indexAutores==-1)
        {
            printf("No se encontro el autor\n");
        }
        else
        {
            libros[indexLibros].codigoDeAutor = auxCodigoAutor;

            do{
            validar = getStringLetras("Ingrese titulo: ",auxTitulo);
            }while(validar == 0);

            if(validar != 0)
            {
                strcpy(libros[indexLibros].tituloLibro,auxTitulo);
                libros[indexLibros].estado = 1;
                libros[indexLibros].codigoDeLibro = auxCodigoLibro;
                printf("Alta de libro exitosa.\nCodigo: %d  Titulo: %s  Codigo de autor: %d\n",auxCodigoLibro,libros[indexLibros].tituloLibro,libros[indexLibros].codigoDeAutor);
                auxCodigoAutor++;
            }
        }
    }
}
void bajaLibro(eLibros libros[], int tam)
{
    int index;
    int codigoLibro;
    char confirma;


        printf("Ingrese el codigo del libro: ");
        scanf("%d", &codigoLibro);
        index = buscarLibro(libros,tam,codigoLibro);

        if(index== -1)
        {
            printf("No se encontro al libro\n");
        }
        else
        {
            confirma = getChar("Desea dar de baja el libro? (S/N): ");
            confirma = toupper(confirma);
            while((confirma!= 'S') && (confirma!= 'N'))
            {
                confirma = getChar("\nerror, ingrese s o n solamente: ");
                confirma = toupper(confirma);
            }
            if(confirma=='S')
            {
                libros[index].estado = 0;
                printf("Baja exitosa!\n");
            }
            else
            {
                printf("No se dio de baja al libro.\n");
            }
        }
}

void modificarLibro(eLibros libros[], int tam,eAutores autores[])
{
    int auxCodigoLibro;
    int indexLibro;
    int validar;
    char auxTitulo[51];
    int auxCodigoAutor;
    int indexAutor;
    char confirma;

        printf("Ingrese codigo del libro a modificar: ");
        scanf("%d",&auxCodigoLibro);
        indexLibro = buscarLibro(libros,tam,auxCodigoLibro);
        if(indexLibro==-1)
        {
            printf("No se encontro el libro\n");
        }else{
            do{
                switch(menuModificacionLibro())
                {
                case '1':
                    printf("El titulo actual es: %s\n",libros[indexLibro].tituloLibro);
                    do{
                    validar = getStringLetras("Ingrese nuevo titulo: ",auxTitulo);
                    }while(validar == 0);

                    confirma = getChar("Seguro quiere modificarlo? (S/N):");
                    confirma = toupper(confirma);

                    if(confirma == 'S')
                    {
                        strcpy(libros[indexLibro].tituloLibro,auxTitulo);
                    }
                    system("pause");
                    break;

                case '2':

                    printf("Ingrese codigo del autor: ");
                    scanf("%d",&auxCodigoAutor);
                    indexAutor = buscarAutor(autores,tam,auxCodigoAutor);

                    if(indexAutor==-1)
                    {
                        printf("No se encontro el autor\n");
                    }else
                    {
                        printf("Ingrese nuevo codigo de autor: ");
                        scanf("%d",&auxCodigoAutor);
                        confirma = getChar("Seguro quiere modificarlo? (N/S):");
                        confirma = toupper(confirma);

                        if(confirma == 'S')
                        {
                            libros[indexLibro].codigoDeAutor = auxCodigoAutor;
                        }
                    }
                    system("pause");
                    break;
                case '3':
                    confirma = 'N';
                    break;
                default:
                    printf("Ingrese opcion correcta \n");
                    system("pause");
                }
            }while (confirma == 'S');
        }
}

