#ifndef LIBROS_H_INCLUDED
#define LIBROS_H_INCLUDED
#include "autor.h"
typedef struct
{
    int codigoDeLibro;
    char tituloLibro[51];
    int codigoDeAutor;
    int estado;
}eLibros;

int menuLibros();
int menuModificacionLibro();
void inicializarLibro(eLibros libros[], int tam);
void listarLibros(eLibros libros[],int tam);
int buscarLibro(eLibros libros[], int tam,int codigo);
void altaLibro(eLibros libros[], int tam, eAutores autores[]);
void bajaLibro(eLibros libros[], int tam);
void modificarLibro(eLibros libros[], int tam,eAutores autores[]);

#endif // LIBROS_H_INCLUDED
