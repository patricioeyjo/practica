#ifndef SOCIO_H_INCLUDED
#define SOCIO_H_INCLUDED
typedef struct
{
    int dia;
    int mes;
    int anio;
}eFecha;

typedef struct
{
    int codigoDeSocio;
    char apellidoSocio[31];
    char nombreSocio[31];
    char sexo;
    char telefono[16];
    char email[31];
    int estado;
    eFecha fechaAsociado;

}eSocio;


int menuModificacion();
void inicializarSocio(eSocio vec[],int tam);
int buscarLibre(eSocio vec[],int tam);
int buscarSocio(eSocio vec[], int tam, int codigoSocio);
void listarSocios(eSocio socio[],int tam);

void altaSocio(eSocio socio[],int tam);
void bajaSocio(eSocio socio[], int tam);
void modificarSocio(eSocio socio[], int tam);


#endif // SOCIO_H_INCLUDED
