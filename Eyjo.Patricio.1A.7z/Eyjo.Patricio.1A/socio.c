#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#include "socio.h"
#include "autor.h"
#include "libros.h"
#include "prestamo.h"
#define TAMLA 10
void inicializarSocio(eSocio vec[],int tam)
{
    int codigoSocioAux=100;
    int i;
    for(i=0; i<tam; i++)
    {
        vec[i].codigoDeSocio=codigoSocioAux+1;
        codigoSocioAux++;
        vec[i].estado= 0;

    }
}

int buscarLibre(eSocio vec[],int tam)
{
    int index;
    int i;
    for(i=0; i<tam; i++)
    {
        if (vec[i].estado == 0)
        {
            index = i;
            break;
        }
        else if(vec[i].estado ==1)
        {
            index = -1;
        }
    }
    return index;
}


int buscarSocio(eSocio vec[], int tam, int codigoSocio)
{
    int index = -1;
    int i;

    for(i=0; i<tam; i++)
    {
        if(vec[i].estado ==1 && vec[i].codigoDeSocio == codigoSocio)
        {
            index=i;
            break;
        }
    }

    return index;
}





void altaSocio(eSocio socio[],int tam)
{
    int auxCodigo;
    int index;
    int esta;
    int validar,validar2;
    char auxApellido[31];
    char auxNombre[31];

    int auxDia;
    int auxMes;
    int auxAnio;

    index=buscarLibre(socio,tam);
    auxCodigo=socio[index].codigoDeSocio;
    if(index == -1)
    {
        printf("\nNo hay lugar en el sistema\n");
    }
    else
    {

        esta = buscarSocio(socio, tam, auxCodigo);

        if(esta != -1)
        {
            printf("Existe un socio con el codigo %d en el sistema\n", auxCodigo);
        }
        else
        {

            do{
                validar=getStringLetras("\ningrese apellido: ",auxApellido);

            }while(validar==0);

            do{
                validar2=getStringLetras("\ningrese nombre: ",auxNombre);
            }while(validar2==0);

            do{
                socio[index].sexo=getChar("\ningrese el sexo: ");
                socio[index].sexo = toupper(socio[index].sexo);
            }while((socio[index].sexo!= 'F') && (socio[index].sexo!= 'M'));

            do{
                getString("\nIngrese telefono: ",socio[index].telefono);


            }while(!esTelefono(socio[index].telefono));


            do{

                getString("Ingrese email: ",socio[index].email);



            }while(!esMail(socio[index].email));


            do
            {
                socio[index].fechaAsociado.dia= getInt("Ingrese dia entre 1 y 31: ");
                auxDia =socio[index].fechaAsociado.dia;
            }
            while(auxDia>31 || auxDia <1);


            do
            {
                socio[index].fechaAsociado.mes=getInt("Ingrese mes entre 1 y 12: ");
                auxMes =socio[index].fechaAsociado.mes;
            }
            while(auxMes>12 || auxMes <1);


            do
            {
                socio[index].fechaAsociado.anio=getInt("Ingrese anio entre 1900 y 2020: ");
                auxAnio =socio[index].fechaAsociado.anio;
            }
            while(auxAnio>2020 || auxAnio <1902);
            strcpy(socio[index].apellidoSocio,auxApellido);
            strcpy(socio[index].nombreSocio,auxNombre);

            socio[index].estado=1;

            printf("\nalta asociado exitosa");

        }

    }

}



void bajaSocio(eSocio socio[], int tam)
{
    int index;
    int codigoSocioAux;
    char confirma;

    printf("Ingrese codigo de socio: ");
    scanf("%d", &codigoSocioAux);
    index = buscarSocio(socio,tam,codigoSocioAux);

    if(index== -1)
    {
        printf("No se encontro al socio\n");
    }
    else
    {
        printf("Desea dar de baja al socio? s/n\n");
        fflush(stdin);
        confirma = getch();

        if(tolower(confirma)=='s')
        {
            socio[index].estado =0;
            printf("Baja exitosa\n");
        }
        else
        {
            printf("No se dio de baja al socio\n");
        }
    }
}

int menuModificacion()
{
    char opcion = '.';

    printf("Modificacion\n");
    printf("A.Apellido\n");
    printf("B.Nombre\n");
    printf("C.Sexo\n");
    printf("D.Telefono\n");
    printf("E.eMail\n");
    printf("F.Cancelar\n");

    opcion = getChar("Ingrese Opcion:\n");
    opcion = toupper(opcion);
    return opcion;
}

void modificarSocio(eSocio socio[], int tam)
{
    int auxCodigo;
    int index;
    char auxNombre[31];
    char auxApellido[31];
    char auxTelefono[16];
    char auxEmail[31];
    char auxSexo;


    char confirma='n';

    printf("Ingrese codigo del socio a modificar:\n");
    scanf("%d",&auxCodigo);

    index = buscarSocio(socio,tam,auxCodigo);

    if(index==-1)
    {
        printf("No se encontro el socio");
    }
    else
    {
        do
        {
            switch(menuModificacion())
            {
            case 'A':
                printf("El apellido actual es: %s\n",socio[index].apellidoSocio);
                getStringLetras("Ingrese nuevo apellido: ",auxApellido);
                if(!esSoloLetras(auxApellido))
                {
                    printf("\nerror el apellido debe estar compuesto por letras");
                    break;
                }

                printf("Desea modificarlo? s/n \n");
                fflush(stdin);
                confirma= getche();
                if(tolower(confirma)== 's')
                {
                    strcpy(socio[index].apellidoSocio,auxApellido);
                }
                else
                {
                    printf("\nno se modifico el apellido.");
                }
                system("pause");
                break;

            case 'B':
                printf("El nombre actual es: %s\n",socio[index].nombreSocio);
                getStringLetras("Ingrese nuevo nombre: ",auxNombre);
                if(!esSoloLetras(auxNombre))
                {
                    printf("\nerror el nombre debe estar compuesto por letras");

                }

                printf("Desea modificarlo? s/n \n");
                fflush(stdin);
                confirma= getche();
                if(tolower(confirma)== 's')
                {
                    strcpy(socio[index].nombreSocio,auxNombre);
                }
                else
                {
                    printf("\nNo se modifico el nombre\n");
                }
                system("pause");
                break;

            case 'C':
                printf("El Sexo actual es: %c\n",socio[index].sexo);
                auxSexo=getChar("Ingrese nuevo sexo (M/F): ");

                if(auxSexo != 'f'&&auxSexo != 'm')
                {
                    printf("\nerror, el sexo solo puede ser f/m\n");
                    break;
                }

                printf("Desea modificarlo? s/n \n");
                fflush(stdin);
                confirma= getche();
                if(tolower(confirma)== 's')
                {
                    socio[index].sexo = toupper(auxSexo);
                }
                else
                {
                    printf("\nNo se modifico el sexo\n");
                }
                system("pause");
                break;

            case 'D':
                printf("El telefono actual es: %s\n",socio[index].telefono);
                getString("Ingrese nuevo telefono: ",auxTelefono);
                if(!esTelefono(auxTelefono))
                {
                    printf("Ingrese un telefono valido\n");
                    break;
                }
                else
                {
                    printf("Desea modificarlo? s/n \n");
                    fflush(stdin);
                    confirma= getche();
                    if(tolower(confirma)== 's')
                    {
                        strcpy(socio[index].telefono,auxTelefono);
                    }
                    else
                    {
                        printf("\nNo se mofidico el telefono\n");
                    }
                }
                system("pause");
                break;

            case 'E':
                printf("El eMail actual es: %s\n",socio[index].email);
                getString("Ingrese nuevo eMail: ",auxEmail);
                if(!esMail(auxEmail))
                {
                    printf("Ingrese un eMail valido\n");
                    break;
                }
                else
                {
                    printf("Desea modificarlo? s/n \n");
                    fflush(stdin);
                    confirma= getche();
                    if(tolower(confirma)== 's')
                    {
                        strcpy(socio[index].email,auxEmail);
                    }
                    else
                    {
                        printf("\nNo se modifico el eMail\n");
                    }
                }
                system("pause");
                break;
            case 'F':
                printf("Seguro desea salir? s/n \n");
                fflush(stdin);
                confirma = getch();
                if(tolower(confirma)== 's')
                {
                    confirma = 'n';
                }
                break;

            default:
                printf("Ingrese opcion correcta\n");
                system("pause");
            }
        }
        while (confirma == 's');
    }
}

void listarSocios(eSocio socio[],int tam)
{
    int i,j;
    eSocio auxSocio;
    printf("\n LISTADO DE SOCIOS POR APELLIDO \n");
    for(i=0; i<TAMLA-1; i++)
    {
        if(socio[i].estado == 0)
        {
            continue;
        }
        for(j=i+1; j<TAMLA; j++)
        {
            if(socio[j].estado == 0)
            {
                continue;
            }
            if(strcmp(socio[i].apellidoSocio,socio[j].apellidoSocio)>0)
            {
                auxSocio = socio[j];
                socio[j]= socio[i];
                socio[i]= auxSocio;
            }
            else if(strcmp(socio[i].apellidoSocio,socio[j].apellidoSocio) == 0)
            {
                if(strcmp(socio[i].nombreSocio,socio[j].nombreSocio)>0)
                {
                    auxSocio = socio[j];
                    socio[j]= socio[i];
                    socio[i]= auxSocio;
                }
            }
        }
    }
}
