#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>

#include "utn.h"
#include "socio.h"
#include "autor.h"
#include "libros.h"
#include "prestamo.h"

#define TAMLA 10







int menu();








int main(){
    char rta = 's';
    char rtaLibros = 'S';
    char rtaAutores = 'S';
    char confirma;
    char confirmaLib;
    char confirmaAut;
    int i;
    eAutores vecDeAutores[TAMLA];/*={{1,"AAA","AAAA"},{2,"BBB","BBBB"},{3,"CCC","CCCC"},{4,"DDD","DDDD"},
                                    {5,"EEE","EEEE"},{6,"FFF","FFFF"},{7,"GGG","GGGG"},{8,"HHH","HHHH"},
                                    {9,"III","IIII"},{10,"JJJ","JJJJ"}};*/
    eLibros vecDeLibros[TAMLA];/*={{101,"AAA",1},{102,"BBB",2},{103,"CCC",3},{104,"DDD",4},
                                    {105,"EEE",5},{106,"FFF",6},{107,"GGG",7},{108,"HHH",8},
                                    {109,"III",9},{110,"JJJ",10}};*/


    eSocio vecSocio[TAMLA];
    inicializarSocio(vecSocio,TAMLA);
    ePrestamo vecPrestamo[TAMLA];
    inicializarPrestamo(vecPrestamo,TAMLA);

    do
    {
        switch(menu())
        {
        case 1:
            altaSocio(vecSocio,TAMLA);
            system("pause");
            break;
        case 2:
            bajaSocio(vecSocio,TAMLA);
            system("pause");
            break;
        case 3:
            modificarSocio(vecSocio,TAMLA);
            break;
        case 4:

        listarSocios(vecSocio,TAMLA);
        for(i=0;i<TAMLA;i++)
        {
        if(vecSocio[i].estado!=0){
        printf("Codigo: %d   Apellido: %s   Nombre: %s   Sexo: %c   Telefono: %s   Email: %s   Fecha: %d/%d/%d \n",vecSocio[i].codigoDeSocio,vecSocio[i].apellidoSocio,vecSocio[i].nombreSocio,vecSocio[i].sexo,vecSocio[i].telefono,vecSocio[i].email,vecSocio[i].fechaAsociado);
                          }
        }

            system("pause");
            break;
        case 5:
            listarLibros(vecDeLibros,TAMLA);
                for(i=0;i<TAMLA;i++){
                                    printf("Codigo del libre: %d   Titulo del libro: %s    Codigo de autor: %d\n", vecDeLibros[i].codigoDeLibro , vecDeLibros[i].tituloLibro , vecDeLibros[i].codigoDeAutor);
                                    }
            system("pause");
            break;
        case 6:
            listarAutores(vecDeAutores,TAMLA);
                for(i=0;i<TAMLA;i++){
                                    printf("Codigo de autor: %d   Nombre de autor: %s    Apellido autor: %s\n", vecDeAutores[i].codigoDeAutor , vecDeAutores[i].nombre , vecDeAutores[i].apellido);
                                    }
            system("pause");
            break;
        case 7:
            altaPrestamo(vecPrestamo,TAMLA,vecSocio,vecDeLibros);
            system("pause");
            break;
        case 8:do
            {
                switch(menuLibros())
                {
                case 'A':
                    altaLibro(vecDeLibros,TAMLA,vecDeAutores);
                    system("pause");
                    break;
                case 'B':
                    modificarLibro(vecDeLibros,TAMLA,vecDeAutores);
                    system("pause");
                    break;
                case 'C':
                    bajaLibro(vecDeLibros,TAMLA);
                    system("pause");
                    break;
                case 'D':
                    confirmaLib=getChar("Desea salir (S/N)?: ");
                    if(toupper(confirmaLib)== 'S')
                    {
                        rtaLibros = 'N';
                    }
                default:
                    printf("Ingrese opcion correcta\n");
                    system("pause");
                }
            }while(rtaLibros == 'S');
            system("pause");
            break;
        case 'F':do
            {
                switch(menuAutores())
                {
                case 'A':
                    altaAutor(vecDeAutores,TAMLA);
                    system("pause");
                    break;
                case 'B':
                    modificacionAutor(vecDeAutores,TAMLA);
                    system("pause");
                    break;
                case 'C':
                    bajaAutor(vecDeAutores,TAMLA);
                    system("pause");
                    break;
                case 'D':
                    confirmaAut=getChar("Desea salir (S/N)?: ");
                    if(toupper(confirmaAut)== 'S')
                    {
                        rtaAutores = 'N';
                    }
                    break;
                default:
                    printf("Ingrese opcion correcta\n");
                    system("pause");
                }
            }while(rtaAutores == 'S');
            break;
        case 9:
            printf("Seguro desea salir? s/n \n");
            fflush(stdin);
            confirma = getch();
            if(tolower(confirma)== 's')
            {
                rta = 'n';
            }
            break;
        default:
            printf("Ingrese opcion correcta\n");
            system("pause");
        }

    }
    while(rta == 's');

    return 0;
}

int menu()
{
    int opcion;

    system("cls");
    printf("---------------ABM --------------\n");
    printf("1.Alta socio\n");
    printf("2.Baja socio\n");
    printf("3.Modificacion\n");
    printf("4.Listar\n");
    printf("5.Listar libros\n");
    printf("6.Listar autores\n");
    printf("7.Prestamos\n");
    printf("8.Menu autor y libro\n");
    printf("9.Salir\n");
    printf("Elija una opcion:");
    scanf("%d",&opcion);

    return opcion;
}







