float pedirFloat(char mensaje[]);
int pedirInt(char mensaje[]);
char pedirChar(char mensaje[]);

int validarEntero(int dato,int min, int max,char mensaje);


int esNumerico(char str[]);
int esAlfaNumerico(char str[]);
int esSoloLetras(char str[]);

void getString(char mensaje[],char imput[]);
int getStringLetras(char mensaje[],char imput[]);
int getStringNumeros(char mensaje[],char imput[]);






