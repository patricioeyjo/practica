#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "biblotecaValidar.h"


typedef struct
{
    int Id;
    char Nombre[50];
    char Apellido[50];
    int Edad;
    int IdLocalidad;
    int estado;
} Persona;

typedef struct
{
    int Id;
    char Descripcion[50];
} Localidad;

Localidad construirLocalidad();
Persona construirPersona(int IdDeLocalidad);
int cargarLocalidades(Localidad arrayLocalidad[],int tam);
void mostrarLocalidad(Localidad localidad);
void mostrarListadoLocalidad(int cantidadRegistros,Localidad listado[]);
void inicializarListadoPersonas(Persona arrayPersonas[],int tam,int valor);






int main()
{

    Localidad localidades[3];
    cargarLocalidades(localidades,3);
    mostrarListadoLocalidad(3,localidades);



    return 0;
}

Localidad construirLocalidad()
{
    Localidad retornarLocalida;
    printf("ingrese el id ");
    scanf("%d",&retornarLocalida.Id);
    printf("ingrese la descripcion: ");
    fflush(stdin);
    gets(retornarLocalida.Descripcion);

    return retornarLocalida;

}
Persona construirPersona(int IdDeLocalidad)
{
    Persona retornarPersona;
    printf("ingrese el nombre ");
    fflush(stdin);
    gets(retornarPersona.Nombre);
    printf("ingrese el apellido: ");
    fflush(stdin);
    gets(retornarPersona.Apellido);
    printf("ingrese edad: ");
    scanf("%d",&retornarPersona.Edad);
    return retornarPersona;
}

int cargarLocalidades(Localidad arrayLocalidad[],int tam)
{
    int i;
    int retorno=-1;
    if(tam>0)
    {
        retorno=0;
        for(i=0; i<tam; i++)
        {
            arrayLocalidad[i]=construirLocalidad();
        }
    }

    return retorno;
}

void mostrarLocalidad(Localidad localidad)
{

    printf("\nID: %d",localidad.Id);
    printf("\nNombre: %s",localidad.Descripcion);

}

void mostrarListadoLocalidad(int cantidadRegistros,Localidad listado[])
{
    int i;
    for(i=0; i<cantidadRegistros; i++)
    {
        mostrarLocalidad(listado[i]);
    }
}

void inicializarListadoPersonas(Persona listado[],int tam,int valor)
{
    int i;
    for(i=0; i<tam; i++)
    {
        listado[i].Id=valor;
    }
}

int buscarLugar(Persona listado[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        if(listado[i].estado!=-1)
        {
            return i;
        }
    }
    return -1;
}



int cagarPersona(int tam,Persona listado[])
{
    int indice;
    indice=buscarLugar(listado,tam);
    if(indice!=-1)
    {
        listado[indice]=construirPersona(3);
    }
    return indice;
}

void BorrarPersona(int tam,Persona listado[],Persona persona)
{
    int indice;
    indice=buscarPersona(tam,listado,persona);
    if(indice!=-1)
    {
        listado[indice].estado=1;
    }
    return indice;
}

int buscarPersona(int tam,Persona listado[],Persona persona)
{
    int i;
    for(i=0;i<tam;i++)
        {
        if(listado[i].id==persona.Id)
            {
            return i;
            }
        }
    return -1;
}
