#include <stdio.h>
#include <stdlib.h>
int pedirDato(int min, int max, int*valor, int intentos, char*mensaje,char* error);
int main()
{
int x;
int ok;
ok=pedirDato(0, 10, &x,3,"ingrese nota: ","error la nota debe ");
if(ok==)
    {
    printf("usted ingreso el numero %d \n\", x);
    }else
        {
        printf("no se pudo obtene el dato");
        }


return=0;
}
int pedirDato(int min, int max, int*valor, int intentos,char*mensaje,char* error)
    {
    int edad;
    int todoOk=0;
    int contador=0;
    printf("ingrese una edad entre %d y %d: ",min,max);
    scanf("%d",&edad);

    while((edad < min || edad > max)&&contador < intentos)
        {
            contador++;
            if(contador==intentos)
                {
                break;
                }
        printf("Error, reingresa una edad");
        scanf("%d",&edad);

        }
        if (contador<=intentos);
            {
            *valor=edad;
            todoOk=1;
            }
   return todoOk;
    }
