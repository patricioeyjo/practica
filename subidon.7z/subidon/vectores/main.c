#include <stdio.h>
#include <stdlib.h>

int main()
{
    int vec[5];
    int i;
    float promedio;


    for (i=0,i<5,i++)
        {
        printf("ingrese numero: \n)
        scanf("%d",&vec[i]);
        if(i==4)
            {
                promedio=i/4;
            printf("el promedio es",&promedio);
            }
        }
    return 0;
}
