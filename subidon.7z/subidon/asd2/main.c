#include <stdio.h>
#include <stdlib.h>
void unaFuncion(int*b);
int main()
{
    int x=5;
    unaFuncion(&x);
    printf("%d\n\n", x);

    return 0;
}
void unaFuncion(int*b)
    {
    int num;
    printf("ingrese un numero: ");
    scanf("%d",&num);
    *b=num;
    }
